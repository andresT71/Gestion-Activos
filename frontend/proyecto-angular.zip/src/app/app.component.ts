import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: `
    <nav class="navbar navbar-dark bg-dark mb-4">
      <div class="container">
        <a class="navbar-brand" href="#">Inventario TI</a>
      </div>
    </nav>
    <div class="container pb-5">
      <router-outlet />
    </div>
  `
})
export class AppComponent {}
