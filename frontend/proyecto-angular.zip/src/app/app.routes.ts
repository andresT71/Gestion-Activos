import { Routes } from '@angular/router';
import { LoginComponent } from './features/login/login.component';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { RegistroComponent } from './features/registro/registro.component';
import { EscaneoComponent } from './features/escaneo/escaneo.component';
import { ReportesComponent } from './features/reportes/reportes.component';

export const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'registro', component: RegistroComponent },
  { path: 'escaneo', component: EscaneoComponent },
  { path: 'reportes', component: ReportesComponent },
  { path: '**', redirectTo: '' }
];
