import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ZXingScannerModule } from '@zxing/ngx-scanner';

@Component({
  standalone: true,
  selector: 'app-escaneo',
  imports: [CommonModule, ZXingScannerModule],
  template: `
  <div class="card p-3 shadow-sm">
    <h5 class="mb-3">Escanear QR</h5>
    <zxing-scanner (scanSuccess)="onScan($event)"></zxing-scanner>
    <div class="mt-3">
      <label class="form-label">Último código leído</label>
      <textarea class="form-control" rows="4" [value]="result" readonly></textarea>
    </div>
  </div>
  `
})
export class EscaneoComponent {
  result = '';
  onScan(text: string) { this.result = text; }
}
