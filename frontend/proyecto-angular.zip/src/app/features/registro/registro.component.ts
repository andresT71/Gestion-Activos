import { Component, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { QRCodeModule } from 'angularx-qrcode';
import { StorageService } from '../../shared/storage.service';

@Component({
  standalone: true,
  selector: 'app-registro',
  imports: [CommonModule, ReactiveFormsModule, QRCodeModule],
  template: `
  <div class="row">
    <div class="col-md-6">
      <form class="card p-3 shadow-sm" [formGroup]="form" (ngSubmit)="save()">
        <h5 class="mb-3">Registrar Activo</h5>
        <div class="mb-3">
          <label class="form-label">Código</label>
          <input class="form-control" formControlName="id" placeholder="ACT-0001">
        </div>
        <div class="mb-3">
          <label class="form-label">Nombre</label>
          <input class="form-control" formControlName="name" placeholder="Notebook Lenovo">
        </div>
        <div class="mb-3">
          <label class="form-label">Ubicación</label>
          <input class="form-control" formControlName="location" placeholder="Bodega / Oficina">
        </div>
        <div class="mb-3">
          <label class="form-label">Serie</label>
          <input class="form-control" formControlName="serial" placeholder="SN123456">
        </div>
        <button class="btn btn-primary" type="submit" [disabled]="form.invalid">Guardar y Generar QR</button>
      </form>
    </div>
    <div class="col-md-6">
      <div class="card p-3 shadow-sm">
        <h5 class="mb-3">QR del Activo</h5>
        <div class="qr-box">
          <qrcode [qrdata]="qrData()" [width]="256" [errorCorrectionLevel]="'M'"></qrcode>
        </div>
        <pre class="bg-light p-2 small">{{ qrData() }}</pre>
      </div>
    </div>
  </div>
  `
})
export class RegistroComponent {
  private fb = new FormBuilder();
  form = this.fb.group({
    id: ['', Validators.required],
    name: ['', Validators.required],
    location: [''],
    serial: ['']
  });

  qrData = computed(() => JSON.stringify({
    id: this.form.value.id || '',
    name: this.form.value.name || '',
    location: this.form.value.location || '',
    serial: this.form.value.serial || '',
    ts: new Date().toISOString()
  }));

  constructor(private storage: StorageService) {}

  save() {
    if (this.form.valid) {
      this.storage.save({
        id: this.form.value.id!,
        name: this.form.value.name!,
        location: this.form.value.location ?? '',
        serial: this.form.value.serial ?? '',
        createdAt: new Date().toISOString()
      });
    }
  }
}
