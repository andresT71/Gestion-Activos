import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-login',
  imports: [CommonModule, ReactiveFormsModule],
  template: `
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card p-4 shadow-sm">
        <h4 class="mb-3">Acceso a Inventario TI</h4>
        <form [formGroup]="form" (ngSubmit)="login()">
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input class="form-control" type="email" formControlName="email" placeholder="correo@empresa.com" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Contraseña</label>
            <input class="form-control" type="password" formControlName="password" required>
          </div>
          <button class="btn btn-primary" type="submit" [disabled]="form.invalid">Ingresar</button>
        </form>
      </div>
    </div>
  </div>
  `
})
export class LoginComponent {
  form = this.fb.group({ email: ['', [Validators.required, Validators.email]], password: ['', Validators.required] });
  constructor(private fb: FormBuilder, private router: Router) {}
  login() { if (this.form.valid) this.router.navigateByUrl('/dashboard'); }
}
