import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-dashboard',
  imports: [CommonModule],
  template: `
  <div class="card p-4 shadow-sm">
    <h4 class="mb-3">Bienvenido</h4>
    <div class="d-grid gap-2 d-md-block">
      <button class="btn btn-outline-primary me-2" (click)="go('registro')">Registrar Activo</button>
      <button class="btn btn-outline-primary me-2" (click)="go('escaneo')">Escanear QR</button>
      <button class="btn btn-outline-primary me-2" (click)="go('reportes')">Ver Reportes</button>
      <button class="btn btn-outline-secondary" (click)="go('')">Cerrar Sesión</button>
    </div>
  </div>
  `
})
export class DashboardComponent {
  constructor(private router: Router) {}
  go(path: string) { this.router.navigateByUrl('/' + path); }
}
