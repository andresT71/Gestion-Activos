import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StorageService, Asset } from '../../shared/storage.service';

@Component({
  standalone: true,
  selector: 'app-reportes',
  imports: [CommonModule],
  template: `
  <div class="card p-3 shadow-sm">
    <h5 class="mb-3">Activos Registrados</h5>
    <div class="table-responsive">
      <table class="table table-sm table-striped align-middle">
        <thead>
          <tr>
            <th>Código</th><th>Nombre</th><th>Ubicación</th><th>Serie</th><th>Creado</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let a of assets">
            <td>{{a.id}}</td>
            <td>{{a.name}}</td>
            <td>{{a.location}}</td>
            <td>{{a.serial}}</td>
            <td>{{a.createdAt | date:'short'}}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <button class="btn btn-outline-success" (click)="downloadCSV()" [disabled]="assets.length===0">Descargar CSV</button>
  </div>
  `
})
export class ReportesComponent implements OnInit {
  assets: Asset[] = [];
  constructor(private storage: StorageService) {}
  ngOnInit() { this.assets = this.storage.list(); }

  downloadCSV() {
    const rows = [['Codigo','Nombre','Ubicacion','Serie','Creado'], ...this.assets.map(a => [a.id,a.name,a.location??'',a.serial??'',a.createdAt])];
    const csv = rows.map(r => r.map(x => `"${(x??'').toString().replace('"','""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'activos.csv'; a.click();
    URL.revokeObjectURL(url);
  }
}
